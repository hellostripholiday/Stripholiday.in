# StripHoliday V2
Mobile-first front-end prototype with customer site, offers, demo sign-in, admin dashboard, coupon management, partner onboarding area, bookings/properties/customers navigation.

Important: this version is a prototype. Authentication, database, payment processing, live hotel/activity inventory, booking APIs and production coupon validation still need backend integrations.
